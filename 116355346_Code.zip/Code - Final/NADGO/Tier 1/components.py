# components.py — NADGO Tier-1: core components & dataclasses

import math
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

LOG2E = 1.0 / math.log(2.0)  # nats → bits conversion factor


# --- replace your current epsilon_est with this capped version ---
def epsilon_est(n_t: int, k: int, alpha: float, q_min: float, *, ln2: float = math.log(2.0)) -> float:
    """
    Finite-sample slack in *bits* for per-interval use.
    Uses a conservative cap to avoid dominating Δ̂ when n_t is small.
    """
    if n_t <= 0 or k <= 0:
        return 0.0

    # Original analytic proposal (often too large for tiny n_t):
    l1_bound = math.sqrt(2.0 * math.log(max(2.0, 2.0 * k) / max(alpha, 1e-12)) / float(n_t))
    lipschitz = 1.0 + math.log(1.0 / max(q_min, 1e-12))
    eps_bits_theory = (l1_bound * lipschitz) / ln2

    # Practical cap: keep slack small and decay ~ 1/sqrt(n_t)
    # You can tighten/loosen the cap (0.02 bits) to tune WARN/ABORT rates.
    cap_bits = 0.02
    eps_bits_capped = min(cap_bits, cap_bits / math.sqrt(max(1.0, float(n_t))))  # ≤ 0.02 at n_t=1, smaller afterwards

    # Use the minimum of theoretical and capped slack.
    return float(min(eps_bits_theory, eps_bits_capped))


# ------------------------ NADGO Components ------------------------
class TDesignPadder:
    """Hardware-aware t-design padding with Clifford scaffolds (sim-level)."""

    def __init__(self, t: int = 4, epsilon_des: float = 0.02, overhead_coeff: float = 0.5):
        self.t = t
        self.epsilon_des = epsilon_des
        self.k = overhead_coeff  # scales O(n log n) dummy depth

    def pad_segment(self, seg: dict, n_qubits: int, rng: np.random.Generator) -> dict:
        """Simulate padding by increasing logical depth: O(n log n) layers."""
        seg2 = seg.copy()
        base = max(1, int(self.k * n_qubits * max(1, math.ceil(math.log2(max(2, n_qubits))))))
        jitter = int(rng.integers(0, max(1, base // 5)))
        extra_depth = (base + jitter) * max(1, self.t // 2)
        seg2['depth'] = seg['depth'] + extra_depth
        seg2['t'] = self.t
        seg2['epsilon_des'] = self.epsilon_des
        seg2['pad_extra_depth'] = extra_depth
        return seg2


class ParticleFilterScheduler:
    """Drift-adaptive timing randomisation with a simple particle filter.

    queue_state in [0,1]: higher → narrower jitter (downweights large |particles|).
    """

    def __init__(self, sigma_t: float = 0.8, l_max: float = 10.0):
        self.sigma_t = float(sigma_t)  # jitter scale (ms)
        self.l_max = float(l_max)      # hard cap on absolute delay (ms)
        self.particles: Optional[np.ndarray] = None
        self.last_theta: float = 0.0

    def propose_timing(self, rng: np.random.Generator, queue_state: float) -> float:
        """Propose next dispatch delay (>=0). Higher backlog → narrower jitter."""
        if self.particles is None:
            self.particles = rng.normal(0.0, self.sigma_t / 2.0, 64)

        # Importance weights favour small |particle| when queue is busy
        weights = np.exp(-float(queue_state) * np.abs(self.particles))

        # Robustify against NaN/inf or degenerate sums
        if not np.isfinite(weights).all():
            weights = np.ones_like(self.particles) / len(self.particles)
        else:
            wsum = weights.sum()
            if (not np.isfinite(wsum)) or (wsum <= 0):
                weights = np.ones_like(self.particles) / len(self.particles)
            else:
                weights = weights / wsum

        new_particles = rng.choice(self.particles, size=64, p=weights)
        # Small diffusion noise; keep within ±sigma_t
        new_particles = new_particles + rng.normal(0.0, self.sigma_t / 10.0, 64)
        new_particles = np.clip(new_particles, -self.sigma_t, self.sigma_t)
        self.particles = new_particles

        theta = float(np.median(new_particles))
        # Enforce non-negative delay and l_max cap
        theta = min(max(0.0, theta), self.l_max)
        self.last_theta = theta
        return theta


class CASQUERouter:
    """Topology-aware routing with fidelity–leakage–queue tradeoff.

    Cost = α * noise + β * risk(recency, ema) + queue_coef * queue_len
    The recency risk is smoothed with an EMA and clamped to avoid runaway costs.
    """

    def __init__(self, alpha: float = 0.5, beta: float = 0.7, queue_coef: float = 0.25):
        self.alpha = float(alpha)      # fidelity weight
        self.beta = float(beta)        # leakage risk weight
        self.queue_coef = float(queue_coef)
        self.history: Dict[int, List[float]] = {}   # backend_id -> [use_times]
        self.ema_load: Dict[int, float] = {}        # backend_id -> EMA of recency

    def route_segment(self, segment_id: int, backend_options: List[dict], current_time: float) -> dict:
        """Select backend using a smoothed, clamped recency-risk cost."""
        if not hasattr(self, "history") or self.history is None:
            self.history = {}
        if not hasattr(self, "ema_load") or self.ema_load is None:
            self.ema_load = {}

        for b in backend_options:
            self.history.setdefault(b['id'], [])
            self.ema_load.setdefault(b['id'], 0.0)

        costs: List[Tuple[float, dict]] = []
        for backend in backend_options:
            bid = backend['id']
            noise = float(backend['noise_level'])
            # Recency: higher when last use was recent
            if self.history[bid]:
                last_use = self.history[bid][-1]
                dt = max(1e-3, current_time - float(last_use))
                inst = 1.0 / (0.1 + dt)  # bounded, ~O(10) max when dt→0
            else:
                inst = 0.0

            # Smooth and clamp risk
            ema_prev = self.ema_load.get(bid, 0.0)
            ema = 0.85 * ema_prev + 0.15 * inst
            self.ema_load[bid] = ema

            # Scale gently with total uses to reflect popularity; clamp overall
            popularity = 1.0 + 0.1 * len(self.history[bid])
            risk = min(ema * popularity, 5.0)  # hard clamp

            queue_penalty = float(len(backend['queue'])) * self.queue_coef

            cost = (self.alpha * noise) + (self.beta * risk) + queue_penalty
            costs.append((cost, backend))

        _, best_backend = min(costs, key=lambda x: x[0])
        self.history[best_backend['id']].append(current_time)
        return best_backend


class LeakageMonitor:
    def __init__(self, delta_budget: float, delta_kill: float, beta: float = 0.1,
                 kill_strikes: int = 2, warn_cooldown: int = 1,
                 alpha: float = 1e-3, q_min: float = 1e-3, eps_sync: float = 0.0,
                 prior_strength: float = 50.0):   # NEW
        self.delta_budget = float(delta_budget)
        self.delta_kill = float(delta_kill)
        self.beta = float(beta)
        self.kill_strikes = int(kill_strikes)
        self.warn_cooldown = int(warn_cooldown)

        # NEW (already had alpha/q_min/eps_sync if you followed earlier steps)
        self.alpha = float(alpha)
        self.q_min = float(q_min)
        self.eps_sync = float(eps_sync)
        self.prior_strength = float(prior_strength)  # NEW


        self.feature_alphabet = self._create_feature_alphabet()
        self.reference_dist = self._create_reference_distribution()
        self.audit_log: List[dict] = []

        # hysteresis state
        self._strikes = 0
        self._cooldown = 0

    # Coarser features + longer horizon bins
    def _create_feature_alphabet(self) -> List[str]:
        intervals = [f"int_{b:.1f}" for b in np.arange(0.0, 5.0, 0.5)]  # 0.5ms bins up to 4.5
        backlogs = ["low", "high"]
        batches = ["small", "medium", "large"]
        events = ["calib", "none"]
        alphabet: List[str] = []
        for i in intervals:
            for b in backlogs:
                for bat in batches:
                    for e in events:
                        alphabet.append(f"{i}|{b}|{bat}|{e}")
        return alphabet

    def _create_reference_distribution(self) -> Dict[str, float]:
        """Default to uniform with q_min floor, then renormalise."""
        size = len(self.feature_alphabet)
        base = {f: 1.0 / size for f in self.feature_alphabet}
        # Apply floor + renorm once to guarantee A4
        tmp = {k: max(self.q_min, float(v)) for k, v in base.items()}
        s = sum(tmp.values())
        return {k: tmp[k] / s for k in tmp}

    # ---------- PATCH: robust q_ref loading (floor + renormalise with q_min) ----------
    def load_qref(self, qref: Dict[str, float]) -> None:
        """Load an empirical baseline distribution (smoothed & normalised, alphabet-aligned)."""
        if not qref:
            return
        # Floor with q_min (A4), project onto alphabet, then renormalise.
        tmp = {k: max(self.q_min, float(qref.get(k, 0.0))) for k in self.feature_alphabet}
        s = sum(tmp.values())
        if s <= 0:
            return
        self.reference_dist = {k: tmp[k] / s for k in self.feature_alphabet}

    def extract_features(self, event: dict) -> str:
        di = float(event['dispatch_interval'])
        binned = math.floor(min(4.9, max(0.0, di)) / 0.5) * 0.5
        interval_bin = f"int_{binned:.1f}"

        qb = int(event['queue_backlog'])
        backlog = "low" if qb < 3 else "high"

        bs = int(event['batch_size'])
        shots = int(event.get('shots', max(1, bs)))  # baseline shots per segment
        ratio = bs / max(1, shots)
        batch_size = "small" if ratio < 0.7 else ("large" if ratio > 1.4 else "medium")

        event_type = "calib" if bool(event['calibration_event']) else "none"
        return f"{interval_bin}|{backlog}|{batch_size}|{event_type}"

    def delta_estimate(self, features: List[str]) -> float:
        """
        Compute corrected estimator in bits:
            Δ̂_t = KL(p̂ || q_ref)/ln2 + β + ε_est(n_t,k,α,q_min) + ε_sync
        Idle intervals (no features) return β + ε_sync.
        """
        total = len(features)
        k = len(self.feature_alphabet)

        if total == 0:
            return float(self.beta + self.eps_sync)

        # Counts on fixed alphabet
        counts = {f: 0 for f in self.feature_alphabet}
        for f in features:
            if f in counts:
                counts[f] += 1

        # --- QREF-CENTRED DIRICHLET PRIOR ---
        # p̂ = (counts + τ * q_ref) / (n_t + τ)
        tau = max(0.0, float(self.prior_strength))
        denom = total + tau if tau > 0 else max(1, total)
        if tau > 0:
            p_hat = {f: (counts[f] + tau * self.reference_dist[f]) / denom for f in counts}
        else:
            # Fallback: Laplace α=1 to keep bins > 0 (not expected in practice)
            laplace_alpha = 1.0
            denom = total + laplace_alpha * k
            p_hat = {f: (counts[f] + laplace_alpha) / denom for f in counts}

        # KL(p̂||q_ref) in nats
        kl_nats = 0.0
        for f in self.feature_alphabet:
            p = p_hat[f]
            q = self.reference_dist[f]  # floored & normalised in load_qref
            kl_nats += p * math.log(p / q)

        kl_bits = kl_nats * LOG2E

        # Optional guardrail (useful while tuning)
        max_kl_bits = math.log(k, 2)
        if kl_bits > max_kl_bits + 1e-6:
            print(f"[warn] KL={kl_bits:.3f} > log2(k)={max_kl_bits:.3f} — check q_ref/coverage.")

        # Finite-sample slack (use your capped epsilon_est)
        eps_fs = epsilon_est(n_t=total, k=k, alpha=self.alpha, q_min=self.q_min)
        return float(kl_bits + self.beta + eps_fs + self.eps_sync)

    def check_policy(self, delta_est: float, interval: int) -> dict:
        """
        Hysteretic policy (baseline-friendly):
          • ABORT can only occur on a kill-level interval AND only after
            observing kill-level intervals close in time.
          • Warnings DO NOT accumulate strikes.
          • Any non-kill interval clears strikes; cooldown only gates whether
            consecutive kills are counted as part of the same burst.
        """
        kill_now = bool(delta_est >= self.delta_kill)
        warn_now = (not kill_now) and bool(delta_est > self.delta_budget)

        if kill_now:
            # If we're within the cooldown window, we count this as "consecutive".
            # Otherwise, start a new burst of strikes.
            if self._cooldown > 0:
                self._strikes += 1
            else:
                self._strikes = 1
            # (Re)start cooldown window after a kill-level event.
            self._cooldown = self.warn_cooldown
            decision = 'ABORT' if self._strikes >= self.kill_strikes else 'WARNING'

        elif warn_now:
            # Warns do NOT accumulate strikes; they just refresh the cooldown
            # to remain sensitive to a near-future kill spike.
            decision = 'WARNING'
            self._cooldown = self.warn_cooldown
            self._strikes = 0  # clear any latent strike priming

        else:
            # Clean interval: decay cooldown toward zero and clear strikes.
            decision = 'CONTINUE'
            if self._cooldown > 0:
                self._cooldown -= 1
            self._strikes = 0

        rec = {
            'interval': int(interval),
            'delta_est': float(delta_est),
            'decision': decision,
            'kill_now': kill_now,  # audit helpers
            'warn_now': warn_now,
            'strikes': int(self._strikes),
            'cooldown': int(self._cooldown),
            'timestamp': time.time(),
        }
        self.audit_log.append(rec)
        return rec


# ------------------------ Dataclasses ------------------------
@dataclass
class TimingEvent:
    job_id: int
    segment_id: int
    dispatch_time: float
    dispatch_interval: float
    queue_backlog: int
    execution_time: float
    batch_size: int
    calibration_event: bool
    backend_id: int
    power_factor: float
    shots: int  # baseline shots for ratio features
    completion_time: float       # used to compute sojourn latency
    system_backlog: float        # avg backlog across all backends at dispatch


@dataclass
class SegmentResult:
    seed: int
    attack: str
    n: int
    interval: int
    leak_bits: float
    policy_action: str
    latency: float
    power: float


@dataclass
class EpisodeResult:
    seed: int
    attack: str
    n: int
    total_leak: float
    max_leak: float
    aborted: bool
    mean_fidelity: float
    mean_latency: float
    mean_power: float
    max_queue_any: int           # maximum in-flight queue length across any backend


__all__ = [
    "LOG2E",
    "epsilon_est",
    "TDesignPadder",
    "ParticleFilterScheduler",
    "CASQUERouter",
    "LeakageMonitor",
    "TimingEvent",
    "SegmentResult",
    "EpisodeResult",
]
